// Copyright (c) 2025, Siva and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Renewable Document", {
// 	refresh(frm) {

// 	},
// });
