# Copyright (c) 2025, Siva and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestRenewableDocument(FrappeTestCase):
	pass
